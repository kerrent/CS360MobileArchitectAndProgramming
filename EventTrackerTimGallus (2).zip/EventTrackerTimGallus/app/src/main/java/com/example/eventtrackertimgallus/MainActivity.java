package com.example.eventtrackertimgallus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //Various layout elements used in MainActivity (login)
    EditText userName;
    EditText userPassword;
    Button createAccountButton;
    Button loginButton;
    TextView feedbackText;

    //Declare a database that we will use for user Accounts and user Events.
    UserAccountDatabase userAccountDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Find components for interaction.
        userName = (EditText) findViewById(R.id.userNameText);
        userPassword = (EditText) findViewById(R.id.userPasswordText);
        createAccountButton = (Button) findViewById(R.id.createAccountButton);
        loginButton = (Button) findViewById(R.id.loginButton);
        feedbackText = (TextView) findViewById(R.id.feedbackText);

        //Setup our database
        userAccountDatabase = new UserAccountDatabase(this);

        //Only turn on our buttons if something is in the text fields on the login screen.
        //Add a watcher for text in userName to know if button should be enabled or disabled.
        userName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //
                if(charSequence.toString().equals("")){
                    createAccountButton.setEnabled(false);
                    loginButton.setEnabled(false);
                }
                else{
                    createAccountButton.setEnabled(true);
                    loginButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        //Add a watcher for when our CreateAccountButton is pressed.
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Set up a new UserAccount based on info in the login and password field.
                UserAccount newUser = new UserAccount(userName.getText().toString().trim(), userPassword.getText().toString().trim());

                //Verify no prior users with that username in the db then add newUser then feedback, else feedback.
                UserAccount userFromDB = userAccountDatabase.readUserAccount(userAccountDatabase, newUser);
                if(userFromDB.username.equals("")) {
                    boolean result = userAccountDatabase.createNewUser(userAccountDatabase ,newUser);
                    //Add feedback
                    if (result){
                        feedbackText.setText("New account for username " + newUser.username + " created successfully");
                    }
                    else {
                        feedbackText.setText("New user account failed to create");
                    }
                }
                else {
                    //Account with that username already in db, give feedback to user.
                    feedbackText.setText("Account already exists with username " + userFromDB.username + " ,please try another.");
                }

            }

        });

        //Add a watcher for when our loginButton is pressed.
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Set up a new UserAccount based on info in the login and password field.
                UserAccount loginUser = new UserAccount(userName.getText().toString().trim(), userPassword.getText().toString().trim());

                UserAccount userFromDB = userAccountDatabase.readUserAccount(userAccountDatabase ,loginUser);

                //if the username is found and the username and password from the database match those in login fields, load the events grid screen.  Else feedback.
                if(userFromDB.username != "") {
                    if(userFromDB.username.equals(loginUser.username) && userFromDB.password.equals(loginUser.password)) {
                        //login
                        Intent loginIntent = new Intent(MainActivity.this, EventScreen.class);
                        loginIntent.putExtra("user", userFromDB.username); //pass along our username so we know what account to populate the events in the grid for.
                        startActivity(loginIntent);
                        //Add feedback
                        feedbackText.setText("login successful");
                    }
                    else {
                        //Add feedback
                        feedbackText.setText("incorrect password");
                    }
                }
                else {
                    //Add feedback
                    feedbackText.setText("no user by this username");
                }

            }

        });
    }


}