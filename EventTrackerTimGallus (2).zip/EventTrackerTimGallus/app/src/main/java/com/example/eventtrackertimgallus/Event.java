package com.example.eventtrackertimgallus;

public class Event {
    public String id;
    public String username;
    public String eventName;
    public String dateTime;
    public String description;

    Event() {}

    Event(String user, String event, String date, String descript){
        this.username = user;
        this.eventName = event;
        this.dateTime = date;
        this.description = descript;
    }


}
