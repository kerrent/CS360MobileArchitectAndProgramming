package com.example.eventtrackertimgallus;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Pop extends AppCompatActivity {
/*
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((R.layout.event_add_layout));
        Button createEventPopupButton = (Button) findViewById(R.id.eventButton);

        createEventPopupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(EventScreen.this, Pop.class));
            }
        });
    }*/
}
