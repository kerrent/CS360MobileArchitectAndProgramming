package com.example.eventtrackertimgallus;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserAccountDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "UserAccount.db";
    private static final int VERSION = 3;

    public UserAccountDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //Information for the user login table
    private static final class UserLoginTable {
        private static final String TABLE_NAME = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    //Information for the events table
    private static final class EventTable {
        private static final String TABLE_NAME = "events";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_EVENTNAME = "eventname";
        private static final String COL_DATETIME = "datetime";
        private static final String COL_DESCRIPTION = "description";
    }


    //creating our tables on create.
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserLoginTable.TABLE_NAME + " (" +
                UserLoginTable.COL_ID + " integer primary key autoincrement, " +
                UserLoginTable.COL_USERNAME + " text, " +
                UserLoginTable.COL_PASSWORD + " text)");
        db.execSQL("create table " + EventTable.TABLE_NAME + " (" +
                EventTable.COL_ID + " integer primary key autoincrement, " +
                EventTable.COL_USERNAME + " text, " +
                EventTable.COL_EVENTNAME + " text, " +
                EventTable.COL_DATETIME + " text, " +
                EventTable.COL_DESCRIPTION + " text)");
    }

    //dropping the tables and recreating them when version number changes.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserLoginTable.TABLE_NAME);
        db.execSQL("drop table if exists " + EventTable.TABLE_NAME);
        onCreate(db);
    }

    //Get a list of all events associated with the username
    public List<Map<String, String>> getUserEvents(UserAccountDatabase uad ,String currentUser) {

        List<Map<String, String>> usersEvents = new ArrayList<Map<String, String>>();

        SQLiteDatabase db = uad.getReadableDatabase();

        String sql = "select * from " + EventTable.TABLE_NAME;

        Cursor cursor = db.rawQuery(sql, null);

        //Fill our event list with what is returned in cursor.
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                Map<String, String> eventData = new HashMap<String, String>();
                eventData.put("_id", String.valueOf(cursor.getInt(0)));
                eventData.put("username", cursor.getString(1));
                eventData.put("eventname", cursor.getString(2));
                eventData.put("datetime", cursor.getString(3));
                eventData.put("description", cursor.getString(4));
                if (cursor.getString(1).equals(currentUser)) {
                    usersEvents.add(eventData);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return usersEvents;
    }



    //Create a new event in the event database.
    public boolean createNewEvent(UserAccountDatabase uad, String username, String eventname, String datetime, String descriptions) {
        SQLiteDatabase db = uad.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EventTable.COL_USERNAME, username);
        values.put(EventTable.COL_EVENTNAME, eventname);
        values.put(EventTable.COL_DATETIME, datetime);
        values.put(EventTable.COL_DESCRIPTION, descriptions);

        long result = db.insert(EventTable.TABLE_NAME, null, values);
        db.close();

        if (result == -1) {
            return false;
        }

        return true;
    }

    //Delete an event from the event database.
    public void deleteEvent(UserAccountDatabase uad, Event event) {
        SQLiteDatabase db = uad.getWritableDatabase();
        db.delete(EventTable.TABLE_NAME,EventTable.COL_ID + " = ?", new String[] {event.id.toString()});
        db.close();
    }

    //Edit an event in the event database.
    public boolean updateEvent(UserAccountDatabase uad, Event event) {
        SQLiteDatabase db = uad.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EventTable.COL_USERNAME, event.username);
        values.put(EventTable.COL_EVENTNAME, event.eventName);
        values.put(EventTable.COL_DATETIME, event.dateTime);
        values.put(EventTable.COL_DESCRIPTION, event.description);

        long result = db.update(EventTable.TABLE_NAME, values, EventTable.COL_ID + " = ?", new String[] {event.id.toString()});
        db.close();

        if (result == -1) {
            return false;
        }

        return true;
    }



    //create new user account in the user account database based on the userAccount passed in.
    public boolean createNewUser(UserAccountDatabase uad, UserAccount user) {
        SQLiteDatabase db = uad.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserLoginTable.COL_USERNAME, user.username);
        values.put(UserLoginTable.COL_PASSWORD, user.password);

        long result = db.insert("users", null, values);
        db.close();

        if (result == -1) {
            return false;
        }

        return true;
    }

    //Find and return user account from the user account database with a username matching the passed in user account.
    public UserAccount readUserAccount(UserAccountDatabase uad, UserAccount user) {
        SQLiteDatabase db = uad.getReadableDatabase();

        UserAccount userAccount = new UserAccount();

        //String sql = "select * from " + UserLoginTable.TABLE + " where " + UserLoginTable.COL_USERNAME + " = " + user.username;
        String sql = "select * from " + UserLoginTable.TABLE_NAME;

        Cursor cursor = db.rawQuery(sql, null);

        //If nothing was returned return an empty user account, else process through the user accounts the database has stored and return the user account with the matching username.
        if(cursor.getCount() == 0) {
            cursor.close();
            return userAccount;
        }
        else {
            while(cursor.moveToNext()) {
                if(cursor.getString(1).equals(user.username)){
                    userAccount.username = cursor.getString(1);
                    userAccount.password = cursor.getString(2);
                    cursor.close();
                    return userAccount;
                }
            }
        }

        return userAccount;
    }

}
