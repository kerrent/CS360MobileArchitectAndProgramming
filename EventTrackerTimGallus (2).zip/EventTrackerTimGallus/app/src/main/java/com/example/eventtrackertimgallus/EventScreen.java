package com.example.eventtrackertimgallus;

import static android.app.ProgressDialog.show;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.List;
import java.util.Map;

public class EventScreen extends AppCompatActivity {

    //Declaring various elements in use by EventScreen.
    List<Map<String, String>> usersEvents;
    UserAccountDatabase userAccountDatabase = new UserAccountDatabase(this);
    String currentUser = "";

    //layout elements in use by the popup window.
    private AlertDialog.Builder dialogBuilder;

    private AlertDialog.Builder detailDialogBuilder;
    private AlertDialog dialog;
    private EditText popUp_username, popUp_eventname, popUp_datetime, popUp_description;
    private TextView popUp_id;
    private Button popupSave, popupCancel, popupDelete;

    GridView eventGrid;

    Event tempEvent;

    String[] from = {"_id", "username", "eventname", "datetime", "description"};
    int to[] = {R.id._idPopText, R.id.usernameEventText, R.id.eventName, R.id.eventDateTime, R.id.eventDetails};

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS=0;
    String phoneNo, message;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_screen);
        Button createEventPopupButton = (Button) findViewById(R.id.createEventButton);
        eventGrid = (GridView)findViewById(R.id.eventGrid);
        //sendSMSMessage();

        Intent intent = getIntent();
        currentUser = intent.getStringExtra("user");


        //Button to open the pop up window for creating events.
        createEventPopupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                createNewDialog();
            }
        });

        //Initially populating the grid with events.
        usersEvents =  userAccountDatabase.getUserEvents(userAccountDatabase, currentUser);

        SimpleAdapter adapter = new SimpleAdapter(EventScreen.this, usersEvents, R.layout.event_layout, from, to);
        eventGrid.setAdapter(adapter);

        //Allow clicking items in the grid to open details.
        eventGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                createDetailDialog();
            }
        });
    }
/*
    protected void sendSMSMessage() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_Granted) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {

            }
            else {
                ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
    }
*/
    //Creating our popup window for updating and deleting.
    public void createDetailDialog(){
        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.layouttest, null);
        popUp_id = (TextView) contactPopupView.findViewById(R.id._idPopText);
        popUp_username = (EditText) contactPopupView.findViewById(R.id.createUsername);
        popUp_eventname = (EditText) contactPopupView.findViewById(R.id.eventCreateEditText);
        popUp_datetime = (EditText) contactPopupView.findViewById(R.id.eventCreateDateTime);
        popUp_description = (EditText) contactPopupView.findViewById(R.id.eventCreateDescription);
        popupSave = (Button) contactPopupView.findViewById(R.id.createEvent);
        popupCancel = (Button) contactPopupView.findViewById(R.id.cancelCreate);
        popupDelete = (Button) contactPopupView.findViewById(R.id.deleteEvent);

        //set the text on the button based on context
        popupSave.setText("Update");
        popupDelete.setActivated(true);
        popupDelete.setVisibility(View.VISIBLE);

        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        //The save now update button updates when pressed.
         popupSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tempEvent.id = popUp_id.getText().toString();
                tempEvent.username = popUp_username.getText().toString();
                tempEvent.eventName = popUp_eventname.getText().toString();
                tempEvent.dateTime = popUp_datetime.getText().toString();
                tempEvent.description = popUp_description.getText().toString();

                userAccountDatabase.updateEvent(userAccountDatabase, tempEvent);
                usersEvents =  userAccountDatabase.getUserEvents(userAccountDatabase, currentUser);
                dialog.dismiss();
                SimpleAdapter adapter = new SimpleAdapter(EventScreen.this, usersEvents, R.layout.event_layout, from, to);
                eventGrid.setAdapter(adapter);
            }
        });

        //Button dismisses the pop up window without creating an event.
        popupCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        //Button deletes event
        popupDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tempEvent.id = popUp_id.getText().toString();
                tempEvent.username = popUp_username.getText().toString();
                tempEvent.eventName = popUp_eventname.getText().toString();
                tempEvent.dateTime = popUp_datetime.getText().toString();
                tempEvent.description = popUp_description.getText().toString();

                userAccountDatabase.deleteEvent(userAccountDatabase, tempEvent);
                dialog.dismiss();
                SimpleAdapter adapter = new SimpleAdapter(EventScreen.this, usersEvents, R.layout.event_layout, from, to);
                eventGrid.setAdapter(adapter);
            }
        });

    }




    //Creating our popup window for creating events.
    public void createNewDialog(){
        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.layouttest, null);
        popUp_username = (EditText) contactPopupView.findViewById(R.id.createUsername);
        popUp_eventname = (EditText) contactPopupView.findViewById(R.id.eventCreateEditText);
        popUp_datetime = (EditText) contactPopupView.findViewById(R.id.eventCreateDateTime);
        popUp_description = (EditText) contactPopupView.findViewById(R.id.eventCreateDescription);
        popupSave = (Button) contactPopupView.findViewById(R.id.createEvent);
        popupCancel = (Button) contactPopupView.findViewById(R.id.cancelCreate);
        popupDelete = (Button) contactPopupView.findViewById(R.id.deleteEvent);

        popupSave.setText("Create");
        popupDelete.setActivated(false);
        popupDelete.setVisibility(View.INVISIBLE);
        popUp_username.setText(currentUser);

        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        //Pressing the create event button in the pop up window creates a new event in the database based on the fields in the pop up window, closes the window and repopulates the grid view.
        popupSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userAccountDatabase.createNewEvent(userAccountDatabase, currentUser, popUp_eventname.getText().toString(), popUp_datetime.getText().toString(), popUp_description.getText().toString());
                dialog.dismiss();
                usersEvents =  userAccountDatabase.getUserEvents(userAccountDatabase, currentUser);

                SimpleAdapter adapter = new SimpleAdapter(EventScreen.this, usersEvents, R.layout.event_layout, from, to);
                eventGrid.setAdapter(adapter);
            }
        });

        //Button dismisses the pop up window without creating an event.
        popupCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
}