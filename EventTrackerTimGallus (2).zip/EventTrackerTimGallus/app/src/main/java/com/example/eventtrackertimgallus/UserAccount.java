package com.example.eventtrackertimgallus;

import android.annotation.SuppressLint;

public class UserAccount {
    public String username = "";
    public String password = "";



    UserAccount() {}
    //TODO: Change the above to privates and add getter and setters to use with them?
    UserAccount(String name, String pass) {
        this.username = name;
        this.password = pass;
    }

}
